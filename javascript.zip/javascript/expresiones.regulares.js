// Las expresiones regulares son patrones usados parar hacer match con combinaciondes de caracteres 
// en formato String, en javaScript una expresion regular es un objeto.

// Estos patrones son usados con los metodos exce() y test() del objeto RegExp, and con los metdos
// match, matchAll, replace, replaceAll y split
